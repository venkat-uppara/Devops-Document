#!/usr/bin/env bash

MODE="cluster"
DRIVER_MEMORY="1G"
EXECUTOR_MEMORY="1G"
NUM_EXECUTORS=1
EXECUTOR_CORES=1
QUEUE="DBP"
APP_CONFIG="dev.conf"
KEYTAB="devtest1.keytab"
JAAS_CONF="dev_kafka_jaas.conf"
KS_KAFKA="dev_kafka_keystore.jks"
TS_KAFKA="dev_kafka_truststore.jks"
SR_KS="dev_sr_keystore"
HWC_JAR="/usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.0.103-1.jar"
