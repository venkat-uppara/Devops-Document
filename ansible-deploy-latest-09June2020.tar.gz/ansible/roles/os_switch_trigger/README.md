os_switch_trigger
=========

Role to switch off automatic triggers in openshift by executing 'oc set triggers' call

Requirements
------------

Requires active OpenShift user session to perform API calls using 'oc' tool.

Role Variables
--------------

* __os_triggers_enabled__ - boolean flag to enable/disable triggers
* __oc_services_to_deploy__ - output list of microservices for processing based on input tags   

Dependencies
------------

N/A

Example Playbook
----------------

```
    - include_role:
        name: os_switch_trigger
      vars:
        os_triggers_enabled: True      
```    

Author Information
------------------

Konstantin Dektyarev <konstantin.dektyarev@aciworldwide.com>
