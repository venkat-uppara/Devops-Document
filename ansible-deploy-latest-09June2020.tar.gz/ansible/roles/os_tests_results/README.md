os_tests_results
=========

Creates temporary folder on jumpbox and copies report files to it using 'oc cp' command 
(no longer using 'oc rsync' since OCP 3.11).

Requirements
------------

Should be executed on OS client node with 'oc' tool available

Role Variables
--------------

Following variables should be set to execute this role:

    service_to_process.project, OS project in which tests will be executed

Dependencies
------------

N/A

Example Playbook
----------------

    - hosts: [oc_client]
      roles:
         - { role: os_tests_results }

OR

    - include_role:
        name: os_tests_results

Author Information
------------------

Denis Shpilevsky <denis.shpilevsky@aciworldwide.com>
Alan Mullane <alan.mullane@aciworldwide.com>
