os_logout
=========

Logs out from OpenShift console

Requirements
------------

Should be executed on OS client node with 'oc' tool available.

Role Variables
--------------

N/A

Dependencies
------------

N/A

Example Playbook
----------------

    - hosts: [oc_client]
      roles:
         - { role: os_logout }

OR
    tasks:

    - include_role:
        name: os_logout

Author Information
------------------

Konstantin Dektyarev <konstantin.dektyarev@aciworldwide.com>
