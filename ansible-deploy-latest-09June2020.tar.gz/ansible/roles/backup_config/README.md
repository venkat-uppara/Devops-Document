backup_config
=========

This role creates backup configuration of running services in OpenShift based on the input tags provided.

Requirements
------------

This role requires 'process_tags' role to be pre-executed as well as active OpenShift user session to perform API calls using 'oc' tool.

Role Variables
--------------

* __oc_services_to_deploy__ - output list of microservices for processing based on input tags   

Dependencies
------------

N/A

Example Playbook
----------------

```
    - include_role:
        name: backup_config
```    

Author Information
------------------

Konstantin Dektyarev <konstantin.dektyarev@aciworldwide.com>
