#!/usr/bin/env python

import argparse
import os
import yaml

# set below describes fields which can be removed from 'metadata' section of openshift yaml configuration
METADATA_FILEDS_TO_REMOVE = {"creationTimestamp", "resourceVersion", "selfLink", "uid"}

# set containing annotation fields to be removed from 'annotations' section nested in 'metadata' of openshift yaml configuration
ANNOTATION_FILEDS_TO_REMOVE = {"kubectl.kubernetes.io/last-applied-configuration"}


def parse_arguments():
  parser = argparse.ArgumentParser(description='Process OS yaml files, removes unnecessary metadata and annotations')    
  parser.add_argument('yaml_file', help='yaml file to process')
  return parser.parse_args()


def remove_metadata_fields(metadata_node):
  for metadata_field_to_filter in METADATA_FILEDS_TO_REMOVE:
    popped_value = metadata_node.pop(metadata_field_to_filter, None)  
    if popped_value:
      print(metadata_field_to_filter + " " + str(popped_value) + " was removed")


def remove_annotations_section(annotations_section):  
  for annotation_field_to_filter in ANNOTATION_FILEDS_TO_REMOVE:
    popped_value = annotations_section.pop(annotation_field_to_filter, None) 
    if popped_value:
      print(annotation_field_to_filter + " " + str(popped_value) + " was removed")


def process_yaml(template_yaml):
  for os_entity in template_yaml["items"]:
    if "status" in os_entity:
      popped_value = os_entity.pop("status", None)       
      if popped_value:
        print("status " + str(popped_value) + " was removed")
    if "metadata" in os_entity:
      remove_metadata_fields(os_entity["metadata"])
      if "annotations" in os_entity["metadata"]:
        remove_annotations_section(os_entity["metadata"]["annotations"])  


# taken from https://stackoverflow.com/a/45004775
def repr_str(dumper, data):
  if '\n' in data:
    return dumper.represent_scalar(u'tag:yaml.org,2002:str', data, style='|')
  if '\t' in data:
    return dumper.represent_scalar(u'tag:yaml.org,2002:str', data, style='|')
  return dumper.org_represent_str(data)

# entry point
def main():
  args = parse_arguments()
  os_template = yaml.load(open(args.yaml_file, "r"))

  process_yaml(os_template)  

  yaml.SafeDumper.org_represent_str = yaml.SafeDumper.represent_str
  yaml.add_representer(str, repr_str, Dumper=yaml.SafeDumper)
  yaml.safe_dump(os_template, open(args.yaml_file, "w"))  


if __name__ == '__main__':
  main()