process_tags
=========

Role for processing Ansible playbook tags and build the list of services for further deployment/processing roles.
Please pay attention to task order in this role since it defines the order which services will be processed. 

Requirements
------------

Should be first (before execution of any other task). It is recommended to put this role in pre_tasks section.

Role Variables
--------------

* __os_templates__ - dictionary (defined in vars/common.yml) which contains basic definition of service 
such as template file location, certificates, docker image origin, etc.
* __oc_services_to_deploy__ - output list of microservices for processing based on input tags   

Dependencies
------------

N/A

Example Playbook
----------------

    - hosts: [oc_client]
      roles:
         - { role: process_tags }

OR

    pre_tasks:

    - include_role:
        name: process_tags

Author Information
------------------

Konstantin Dektyarev <konstantin.dektyarev@aciworldwide.com>
