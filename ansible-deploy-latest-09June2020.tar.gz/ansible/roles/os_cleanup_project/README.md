os_cleanup_project
=========

Cleans up the environment.

Requirements
------------

Require active OS login session, *process_tags* role must be pre-executed

Role Variables
--------------

Following variables should be set to execute this role:

* __oc_services_to_deploy__, a list of services to remove from environment

Dependencies
------------

N/A

Example Playbook
----------------

    - hosts: [oc_client]
      roles:
         - { role: os_cleanup_project }

OR

    - include_role:
        name: os_cleanup_project

Author Information
------------------

Konstantin Dektyarev <konstantin.dektyarev@aciworldwide.com>
