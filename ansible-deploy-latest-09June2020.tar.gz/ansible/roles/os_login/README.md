os_login
=========

Logs in to OpenShift console by executing 'oc login'.

Requirements
------------

Should be executed on OS client node with 'oc' tool available

Role Variables
--------------

Following variables should be set to execute this role:

    oc_user, an OpenShift user login
    oc_password, passphrase or OS system token
    oc_host, url to OS entrypoint like dosmaster.ose.am.tsacorp.com:8443

Dependencies
------------

N/A

Example Playbook
----------------

    - hosts: [oc_client]
      roles:
         - { role: os_login }

OR

    - include_role:
        name: os_login

Author Information
------------------

Konstantin Dektyarev <konstantin.dektyarev@aciworldwide.com>
