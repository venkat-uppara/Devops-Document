os_restore_backup
=========

Role to restore backup OpenShift configuration stored on ansible host. 
Applied configuration will completely replace current config in OpenShift since it uses 'oc replace' call.

Requirements
------------

This role is service based so it requires 'process_tags' to be pre-executed and 'oc_services_to_deploy' dictionary should be initialized.
Requires active OpenShift user session to perform API calls using 'oc' tool.

Role Variables
--------------

* __oc_services_to_deploy__ - output list of microservices for processing based on input tags   

Dependencies
------------

N/A

Example Playbook
----------------

```
    - name: "Restore OS backup"
      include_role:
        name: os_restore_backup   
```    

Author Information
------------------

Konstantin Dektyarev <konstantin.dektyarev@aciworldwide.com>
