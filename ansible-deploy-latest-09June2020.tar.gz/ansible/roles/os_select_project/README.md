os_select_project
=========

Selects OpenShift project using 'oc project <project_name>' switch command.

Requirements
------------

This role should be run on OpenShift client node with 'oc' tool installed.

Role Variables
--------------

An 'os_project' parameter should be set for this role. This parameter should contain OpenShift project name to switch onto.

Dependencies
------------

N/A

Example Playbook
----------------

Make sure you pass os_project variable to this role (you can use reference to another variable: '{{ oc_private_project }}' ):

    - hosts: [oc_client]
      roles:
         - { role: os_select_project, os_project: 'project_name', tags ['private', 'all'] }

Author Information
------------------

Konstantin Dektyarev <konstantin.dektyarev@aciworldwide.com>
