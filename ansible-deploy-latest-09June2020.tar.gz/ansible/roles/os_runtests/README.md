os_runtests
=========

Creates pod with specific test suite by executing 'oc run' command.

Requirements
------------

Should be executed on OS client node with 'oc' tool available

Role Variables
--------------

Following variables should be set to execute this role:

    service_to_process.app, an OpenShift application name
    service_to_process.project, OS project in which tests will be executed

Dependencies
------------

N/A

Example Playbook
----------------

    - hosts: [os_runtests]
      roles:
         - { role: os_runtests }

OR

    - include_role:
        name: os_runtests

Author Information
------------------

Denis Shpilevsky <denis.shpilevsky@aciworldwide.com>
