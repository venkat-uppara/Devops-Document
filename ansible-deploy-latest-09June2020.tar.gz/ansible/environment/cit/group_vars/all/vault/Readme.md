## Vault description

Vault.yml encrypted file by command "ansible-vault encrypt vault.yml"
Vault.yml decrypted file by command "ansible-vault decrypt vault.yml"

After launching an ansible playbook, you need to specify an additional parameter "--ask-vault-pass" and enter the password from the vault.yml

If you use ansible locally, then it is better to take an example from the vault.template, and indicate your credentials in it.
 