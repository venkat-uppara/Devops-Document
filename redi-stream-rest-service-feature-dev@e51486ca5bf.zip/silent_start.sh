#!/usr/bin/env bash
#!/bin/bash
#auth
principal=srvredi@IPA.AM.TSACORP.COM
keyTab=/home/srvredi/keytabs/srvredi.keytab
kinit $principal -k -t $keyTab

nohup ./start.sh > service.out 2> service.err < /dev/null &