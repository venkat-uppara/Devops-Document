package com.org.aci.stream.service.model;

public class NumRuleInfo {
    public String ServiceName;

    public String NumRuleHits;

    public String ErrorCount;

    public String Answer;

}