package com.org.aci.stream.service.model;
import java.util.List;
import java.util.StringJoiner;

public class ReqModel {
    private String clientId;
    private List<String> currCds;
    private List<String> reasonCodes;
    private List<String> subClientIds;
    private int numberOfMsg;
    private List<String> recommendations;
    private String oidDate;
    private List<String> virtVCardBins;

    public ReqModel(String clientId, List<String> currCds, List<String> subClientIds, int numberOfMsg, List<String> recommendations, String oidDate) {
        this.clientId = clientId;
        this.currCds = currCds;
        this.subClientIds = subClientIds;
        this.numberOfMsg = numberOfMsg;
        this.recommendations = recommendations;
        this.oidDate = oidDate;
    }

    public List<String> getVirtVCardBins() {
        return virtVCardBins;
    }

    public void setVirtVCardBins(List<String> virtVCardBins) {
        this.virtVCardBins = virtVCardBins;
    }

    public ReqModel() {
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public List<String> getCurrCds() {
        return currCds;
    }

    public void setCurrCds(List<String> currCds) {
        this.currCds = currCds;
    }

    public List<String> getSubClientIds() {
        return subClientIds;
    }

    public void setSubClientIds(List<String> subClientIds) {
        this.subClientIds = subClientIds;
    }

    public int getNumberOfMsg() {
        return numberOfMsg;
    }

    public void setNumberOfMsg(int numberOfMsg) {
        this.numberOfMsg = numberOfMsg;
    }

    public List<String> getRecommendations() {
        return recommendations;
    }

    public void setRecommendations(List<String> recommendations) {
        this.recommendations = recommendations;
    }

    public String getOidDate() {
        return oidDate;
    }

    public List<String> getReasonCodes() {
        return reasonCodes;
    }

    public void setReasonCodes(List<String> reasonCodes) {
        this.reasonCodes = reasonCodes;
    }

    public void setOidDate(String oidDate) {
        this.oidDate = oidDate;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", ReqModel.class.getSimpleName() + "[", "]")
                .add("clientId='" + clientId + "'")
                .add("currCds=" + currCds)
                .add("subClientIds=" + subClientIds)
                .add("numberOfMsg=" + numberOfMsg)
                .add("recommendations=" + recommendations)
                .add("oidDate='" + oidDate + "'")
                .toString();
    }
}
