package com.org.aci.stream.service.model;

public class RuleMaster
{
    public String RuleSource;

    public String RuleId;

    public String RuleName;

    public String SdsAnswer;

}