#!/bin/bash
# Description  :This Script is used to monitor the job and whenever job fails auto restart the job.
#
# Modification history:
#
# Date         Author               Description
# ===========  ===================  ============================================
# 10/09/2019   Rakesh G             Creation
################################################################################

MOVED to generic restart, Please REMOVE THIS SCRIPT

###APP_NAME="incrementalfailoverjob"

while true
        do
        incrementalfailoverjobStatus=$(yarn application -appStates RUNNING -list | grep $APP_NAME | awk '{print $2}')

        if [ -z "$incrementalfailoverjobStatus" ]
        then
        echo " $APP_NAME is NOT RUNNING, going to start now " | mailx -s "  $APP_NAME is NOT RUNNING, going to restart now " midhun.polisetty@aciworldwide.com kiruba.venkatesh@aciworldwide.com
                  sh ./incremental_failover.sh 
        else
                  echo "\ $APP_NAME is RUNNING, No action required"
        fi

sleep 300
done
