#!/bin/bash
# Description  :This Script is used to monitor the job and whenever job fails auto restart the job.
#
# Modification history:
#
# Date         Author               Description
# ===========  ===================  ============================================
# 10/09/2019   Rakesh G             Creation
################################################################################

MOVED to generic restart script, Please REMOVE THIS SCRIPT

###APP_NAME="historicalfailoverjob"

while true
        do
        historicalfailoverjobStatus=$(yarn application -appStates RUNNING -list | grep $APP_NAME | awk '{print $2}')

        if [ -z "$historicalfailoverjobStatus" ]
        then
        echo " $APP_NAME is NOT RUNNING, going to start now " | mailx -s "  $APP_NAME is NOT RUNNING, going to restart now " midhun.polisetty@aciworldwide.com kiruba.venkatesh@aciworldwide.com
                  sh ./historical_failover.sh 
        else
                  echo "\ $APP_NAME is RUNNING, No action required"
        fi

sleep 300
done
