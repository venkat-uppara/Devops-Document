#!/usr/bin/env bash

#----------------------------------------------------------------------------------------------------
# Name          : redi-historical.sh
#
# Purpose       : Used for starting, restarting, stopping and reading status of a given
#                 service (aka job)
#
# App/Services  : HISTORICAL Microservice and Services offered are
#                 historicalfailoverjob(INACTIVE)
#                 HistoricalIngestionJobID(INACTIVE)
#                 incrementalfailoverjob(INACTIVE)
#                 IncrementalTransfJobID(INACTIVE)
#                 IncrementalIngestionJobID(INACTIVE)
#                 Allclientgroup(INACTIVE)
#                 IncrementalTransfJobID-One(INACTIVE)
#                 IncrementalTransfJobID-Two(INACTIVE)
#                 RSExecBaseHiveYBConsumer(INACTIVE)
#                 bae-transformation(ACTIVE)
#                 bae-transformation-historical(ACTIVE)
#
#----------------------------------------------------------------------------------------------------

# Check arguments
if [[ $# != 3 ]]; then
   echo "Usage: $0 <start/stop> <app version> <job name>"
   echo "Example: $0 start 5.2-SNAPSHOT HistoricalIngestionJobID"
   echo "Example: $0 stop 5.2-SNAPSHOT HistoricalIngestionJobID"
   echo "Example: $0 restart 5.2-SNAPSHOT HistoricalIngestionJobID"
   echo "Example: $0 status 5.2-SNAPSHOT HistoricalIngestionJobID"
   exit 1
fi

# App name and location
appJAR=$APP_HOME/$APP_RELEASE_VERSION/redi-historical/redi-historical-$2.jar

CLASSPATH=/apps/ReDi/ReDi_ext_jars/abris_2.11-2.2.2.jar,\
/apps/ReDi/ReDi_ext_jars/avro-1.8.2.jar,\
/apps/ReDi/ReDi_ext_jars/common-config-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/common-metrics-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/common-utils-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-fw-common-impl-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-fw-spec-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-slf4j-adf-log-common-binder-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-testbundles-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-upf-installer-jaxb-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/encryptor-1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-avro-serializer-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-clients-2.1.0-cp2.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-schema-registry-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-schema-registry-client-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-streams-avro-serde-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/org.osgi.core-4.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/spark-sql-kafka-0-10_2.11-2.3.2.3.1.0.10-1.jar,\
/usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-*.jar,\
/apps/ReDi/lib/avro-1.8.2.jar,\
/apps/ReDi/lib/log4j-core-2.11.1.jar,\
/apps/ReDi/lib/log4j-api-2.11.1.jar,\
/apps/ReDi/lib/ojdbc6-11.2.0.3.jar,\
/apps/ReDi/lib/config-1.3.2.jar,\
/apps/ReDi/lib/spark-avro_2.11-4.0.0.jar,\
/usr/share/java/kafka-rest/annotations-3.0.1.jar,\
/usr/share/java/kafka-rest/avro-1.8.1.jar,\
/usr/share/java/kafka-rest/commons-compress-1.8.1.jar,\
/usr/share/java/kafka-rest/common-utils-4.1.2.jar,\
/usr/share/java/kafka-rest/jackson-core-asl-1.9.13.jar,\
/usr/share/java/kafka-rest/jackson-mapper-asl-1.9.13.jar,\
/usr/share/java/kafka-rest/jcip-annotations-1.0.jar,\
/usr/share/java/kafka-rest/jline-0.9.94.jar,\
/usr/share/java/kafka-rest/jopt-simple-5.0.4.jar,\
/usr/share/java/kafka-rest/jsr305-3.0.1.jar,\
/usr/share/java/kafka-rest/kafka_2.11-1.1.1-cp1.jar,\
/usr/share/java/kafka-rest/kafka-avro-serializer-4.1.2.jar,\
/usr/share/java/kafka-rest/kafka-clients-1.1.1-cp1.jar,\
/usr/share/java/kafka-rest/kafka-json-serializer-4.1.2.jar,\
/usr/share/java/kafka-rest/kafka-rest-4.1.2.jar,\
/usr/share/java/kafka-rest/kafka-schema-registry-client-4.1.2.jar,\
/usr/share/java/kafka-rest/log4j-1.2.17.jar,\
/usr/share/java/kafka-rest/lz4-java-1.4.1.jar,\
/usr/share/java/kafka-rest/metrics-core-2.2.0.jar,\
/usr/share/java/kafka-rest/netty-3.10.5.Final.jar,\
/usr/share/java/kafka-rest/paranamer-2.7.jar,\
/usr/share/java/kafka-rest/scala-library-2.11.12.jar,\
/usr/share/java/kafka-rest/scala-logging_2.11-3.8.0.jar,\
/usr/share/java/kafka-rest/scala-reflect-2.11.12.jar,\
/usr/share/java/kafka-rest/slf4j-api-1.7.25.jar,\
/usr/share/java/kafka-rest/slf4j-log4j12-1.7.25.jar,\
/usr/share/java/kafka-rest/snappy-java-1.1.7.1.jar,\
/usr/share/java/kafka-rest/xz-1.5.jar,\
/usr/share/java/kafka-rest/zkclient-0.10.jar,\
/usr/share/java/kafka-rest/zookeeper-3.4.10.jar,\
/usr/share/java/confluent-common/build-tools-4.1.0.jar,\
/usr/share/java/confluent-common/common-config-4.1.0.jar,\
/usr/share/java/confluent-common/common-metrics-4.1.0.jar,\
/usr/share/java/confluent-common/common-utils-4.1.0.jar,\
/usr/share/java/confluent-common/jline-0.9.94.jar,\
/usr/share/java/confluent-common/log4j-1.2.17.jar,\
/usr/share/java/confluent-common/netty-3.10.5.Final.jar,\
/usr/share/java/confluent-common/slf4j-api-1.7.25.jar,\
/usr/share/java/confluent-common/zkclient-0.10.jar,\
/usr/share/java/confluent-common/zookeeper-3.4.10.jar,\
/apps/ReDi/lib/redi-common-5.2.0.1.jar

## App level config
keyTab=$KEYTAB
principal=$PRINCIPAL
jaasConf=$JAASCONFPATH/$JAASCONFFILE
encryptor=$ENCRYPTORPROPERTIES
certs=$SCHEMAREGPATH/$SCHEMAREGFILE
log4j=$APP_HOME/$APP_RELEASE_VERSION/redi-historical/conf/log4j.properties
kafkaKeytabs=$KEYTABKAFKA

JVM_JAAS=" -Djava.security.auth.login.config="$JAASCONFFILE
JVM_TRUSTSTORE=" -Djavax.net.ssl.trustStore="$SCHEMAREGFILE
extraConf=

if [[ $SCHEMAREGPATH == "" ]]; then
   certs=
fi

if [[ $JAASCONFPATH == "" ]]; then
   jaasConf=
fi

if [[ $3 == "bae-transformation" ]]; then
   appName="bae-transformation-$2"
   appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-historical/conf/bae-transformation-app.conf
   className=com.aciworldwide.ra.redi.rstransflow.actions.RSExecIngestProcess
   extraDriverOptions="spark.driver.extraJavaOptions=-Duser.timezone=UTC -Dconfig.file=bae-transformation-app.conf -Dlog4j.configuration=log4j.properties"$JVM_JAAS
   extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
   extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC -Dconfig.file=bae-transformation-app.conf -Dlog4j.configuration=log4j.properties"$JVM_JAAS
   extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE


   if [[ $METRICS_ENABLED == "Y" ]]; then
      extraConf=" --conf \"spark.driver.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -Dconfig.file=bae-transformation-app.conf -Dlog4j.configuration=log4j.properties  -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-incremental-driver-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.port=9011\" --conf \"spark.executor.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE  -Dconfig.file=bae-transformation-app.conf -Dlog4j.configuration=log4j.properties -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-incremental-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf spark.sql.streaming.metricsEnabled=true "
   fi

   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true --conf spark.datasource.hive.warehouse.use.spark23x.specific.reader=false --conf "spark.executor.extraClassPath=./bae-transformation-app.conf,./encryptor.properties" --conf "spark.driver.extraClassPath=./bae-transformation-app.conf,./encryptor.properties"  --conf spark.cleaner.ttl=3600 "$extraConf

   driverMemory=$BAETRANSFORM_DRIVER_MEMORY
   executorMemory=$BAETRANSFORM_EXECUTOR_MEMORY
   numberOfExecutors=$BAETRANSFORM_NUM_OF_EXECUTOR
   executorCores=$BAETRANSFORM_NUM_OF_CORE
   queueName=$BAETRANSFORM_QUEUE_NAME

   sed -i -e 's#BAETRANSFORM_CHECKPOINTLOCATION#'$BAETRANSFORM_CHECKPOINTLOCATION'#g' $appConfig
   sed -i -e 's#BAETRANSFORM_TOPICS#'$BAETRANSFORM_TOPICS'#g' $appConfig
   sed -i -e 's#BAETRANSFORM_PRODUCER_TOPICS#'$BAETRANSFORM_PRODUCER_TOPICS'#g' $appConfig
   sed -i -e 's#BAETRANSFORM_SCHEMA_TOPICS#'$BAETRANSFORM_SCHEMA_TOPICS'#g' $appConfig
   sed -i -e 's#BAETRANSFORM_MSG_TYPE#'$BAETRANSFORM_MSG_TYPE'#g' $appConfig
   sed -i -e 's#BAETRANSFORM_GROUP_ID#'$BAETRANSFORM_GROUP_ID'#g' $appConfig
   sed -i -e 's#BAETRANSFORM_HIVE_DBURI#'$BAETRANSFORM_HIVE_DBURI'#g' $appConfig
   sed -i -e 's#BAETRANSFORM_HIVE_DBNAME#'$BAETRANSFORM_HIVE_DBNAME'#g' $appConfig
   sed -i -e 's#BAETRANSFORM_HIVE_TYPE#'$BAETRANSFORM_HIVE_TYPE'#g' $appConfig
   sed -i -e 's#BAETRANSFORM_SCHEMA_URI#'$BAETRANSFORM_SCHEMA_URI'#g' $appConfig
fi

if [[ $3 == "bae-transformation-historical" ]]; then
   appName="bae-transformation-historical-$2"
   appConfig=$APP_HOME/$APP_RELEASE_VERSION/redi-historical/conf/application.conf
   className=com.aciworldwide.ra.redi.rstransflow.actions.HistoricalRSExecIngestProcess
   extraDriverOptions="spark.driver.extraJavaOptions=-Duser.timezone=UTC -Dconfig.file=application.conf -Dlog4j.configuration=log4j.properties"$JVM_JAAS
   extraDriverOptions=$extraDriverOptions$JVM_TRUSTSTORE
   extraExecutorOptions="spark.executor.extraJavaOptions=-Duser.timezone=UTC -Dconfig.file=application.conf -Dlog4j.configuration=log4j.properties"$JVM_JAAS
   extraExecutorOptions=$extraExecutorOptions$JVM_TRUSTSTORE


   if [[ $METRICS_ENABLED == "Y" ]]; then
      extraConf=" --conf \"spark.driver.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -Dconfig.file=application.conf -Dlog4j.configuration=log4j.properties  -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-incremental-driver-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.port=9011\" --conf \"spark.executor.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE  -Dconfig.file=application.conf -Dlog4j.configuration=log4j.properties -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-incremental-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf spark.sql.streaming.metricsEnabled=true "
   fi

   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true --conf spark.datasource.hive.warehouse.use.spark23x.specific.reader=false --conf "spark.executor.extraClassPath=./application.conf,./encryptor.properties" --conf "spark.driver.extraClassPath=./application.conf,./encryptor.properties"  --conf spark.cleaner.ttl=3600 "$extraConf

   driverMemory=$BAETRANSFORMHIST_DRIVER_MEMORY
   executorMemory=$BAETRANSFORMHIST_EXECUTOR_MEMORY
   numberOfExecutors=$BAETRANSFORMHIST_NUM_OF_EXECUTOR
   executorCores=$BAETRANSFORMHIST_NUM_OF_CORE
   queueName=$BAETRANSFORMHIST_QUEUE_NAME

   sed -i -e 's#BAETRANSFORMHIST_CHECKPOINTLOCATION#'$BAETRANSFORMHIST_CHECKPOINTLOCATION'#g' $appConfig
   sed -i -e 's#BAETRANSFORMHIST_TOPICS#'$BAETRANSFORMHIST_TOPICS'#g' $appConfig
   sed -i -e 's#BAETRANSFORMHIST_SCHEMA_TOPICS#'$BAETRANSFORMHIST_SCHEMA_TOPICS'#g' $appConfig
   sed -i -e 's#BAETRANSFORMHIST_MSG_TYPE#'$BAETRANSFORMHIST_MSG_TYPE'#g' $appConfig
   sed -i -e 's#BAETRANSFORMHIST_GROUP_ID#'$BAETRANSFORMHIST_GROUP_ID'#g' $appConfig
   sed -i -e 's#BAETRANSFORMHIST_HIVE_DBURI#'$BAETRANSFORMHIST_HIVE_DBURI'#g' $appConfig
   sed -i -e 's#BAETRANSFORMHIST_HIVE_DBNAME#'$BAETRANSFORMHIST_HIVE_DBNAME'#g' $appConfig
   sed -i -e 's#BAETRANSFORMHIST_HIVE_TYPE#'$BAETRANSFORMHIST_HIVE_TYPE'#g' $appConfig
   sed -i -e 's#BAETRANSFORMHIST_SCHEMA_URI#'$BAETRANSFORMHIST_SCHEMA_URI'#g' $appConfig
fi

if [[ $3 == "historicalfailoverjob" ]]; then
   appName="historicalfailoverjob-$2"
   className=com.aciworldwide.ra.redi.rstransflow.actions.HistoricalTransFlowFailedAction
   appConfig=$APP_HOME/$2/redi-historical/conf/rsexec-base-producer.conf

   driverMemory=$HIST_FAILOVER_DRIVER_MEMORY
   executorMemory=$HIST_FAILOVER_EXECUTOR_MEMORY
   numberOfExecutors=$HIST_FAILOVER_NUM_OF_EXECUTOR
   executorCores=$HIST_FAILOVER_NUM_OF_CORE
   queueName=$HIST_FAILOVER_QUEUE_NAME

   sed -i -e 's#HIST_FAILOVER_CHECKPOINTLOCATION#'$HIST_FAILOVER_CHECKPOINTLOCATION'#g' $appConfig
   sed -i -e 's#HIST_FAILOVER_TOPICS#'$HIST_FAILOVER_TOPICS'#g' $appConfig
   sed -i -e 's#HIST_FAILOVER_MSG_TYPE#'$HIST_FAILOVER_MSG_TYPE'#g' $appConfig
   sed -i -e 's#HIST_FAILOVER_GROUP_ID#'$HIST_FAILOVER_GROUP_ID'#g' $appConfig
   sed -i -e 's#HIST_FAILOVER_HIVE_DBURI#'$HIST_FAILOVER_HIVE_DBURI'#g' $appConfig
   sed -i -e 's#HIST_FAILOVER_HIVE_DBNAME#'$HIST_FAILOVER_HIVE_DBNAME'#g' $appConfig
   sed -i -e 's#HIST_FAILOVER_HIVE_TYPE#'$HIST_FAILOVER_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "HistoricalIngestionJobID" ]]; then
   appName="HistoricalIngestionJobID-$2"
   className=com.aciworldwide.ra.redi.rstransflow.actions.HistoricalRSExecIngestProcess
   appConfig=$APP_HOME/$2/redi-historical/conf/rsexec-base-producer.conf
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=false --conf spark.datasource.hive.warehouse.use.spark23x.specific.reader=true --conf "spark.executor.extraClassPath=./application.conf,./encryptor.properties"  "$extraConf

   driverMemory=$HIST_INGEST_DRIVER_MEMORY
   executorMemory=$HIST_INGEST_EXECUTOR_MEMORY
   numberOfExecutors=$HIST_INGEST_NUM_OF_EXECUTOR
   executorCores=$HIST_INGEST_NUM_OF_CORE
   queueName=$HIST_INGEST_QUEUE_NAME

   sed -i -e 's#HIST_INGEST_FAILOVER_CHECKPOINTLOCATION#'$HIST_INGEST_CHECKPOINTLOCATION'#g' $appConfig
   sed -i -e 's#HIST_INGEST_TOPICS#'$HIST_INGEST_TOPICS'#g' $appConfig
   sed -i -e 's#HIST_INGEST_MSG_TYPE#'$HIST_INGEST_MSG_TYPE'#g' $appConfig
   sed -i -e 's#HIST_INGEST_GROUP_ID#'$HIST_INGEST_GROUP_ID'#g' $appConfig
   sed -i -e 's#HIST_INGEST_HIVE_DBURI#'$HIST_INGEST_HIVE_DBURI'#g' $appConfig
   sed -i -e 's#HIST_INGEST_HIVE_DBNAME#'$HIST_INGEST_HIVE_DBNAME'#g' $appConfig
   sed -i -e 's#HIST_INGEST_HIVE_TYPE#'$HIST_INGEST_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "IncrementalIngestionJobID" ]]; then
   appName="redi-incremental-$2"
   className=com.aciworldwide.ra.redi.rstransflow.actions.RSExecIngestProcess
   appConfig=$APP_HOME/$2/redi-historical/conf/rsexec-base-producer.conf
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true --conf spark.datasource.hive.warehouse.use.spark23x.specific.reader=false --conf "spark.executor.extraClassPath=./rsexec-base-producer.conf,./encryptor.properties" --conf "spark.driver.extraClassPath=./rsexec-base-producer.conf,./encryptor.properties"  --conf spark.cleaner.ttl=3600 "$extraConf

   driverMemory=$INCREMENT_INGEST_DRIVER_MEMORY
   executorMemory=$INCREMENT_INGEST_EXECUTOR_MEMORY
   numberOfExecutors=$INCREMENT_INGEST_NUM_OF_EXECUTOR
   executorCores=$INCREMENT_INGEST_NUM_OF_CORE
   queueName=$INCREMENT_INGEST_QUEUE_NAME

   sed -i -e 's#INCREMENT_INGEST_CHECKPOINTLOCATION#'$INCREMENT_INGEST_CHECKPOINTLOCATION'#g' $appConfig
   sed -i -e 's#INCREMENT_INGEST_TOPICS#'$INCREMENT_INGEST_TOPICS'#g' $appConfig
   sed -i -e 's#INCREMENT_INGEST_MSG_TYPE#'$INCREMENT_INGEST_MSG_TYPE'#g' $appConfig
   sed -i -e 's#INCREMENT_INGEST_GROUP_ID#'$INCREMENT_INGEST_GROUP_ID'#g' $appConfig
   sed -i -e 's#INCREMENT_INGEST_HIVE_DBURI#'$INCREMENT_INGEST_HIVE_DBURI'#g' $appConfig
   sed -i -e 's#INCREMENT_INGEST_HIVE_DBNAME#'$INCREMENT_INGEST_HIVE_DBNAME'#g' $appConfig
   sed -i -e 's#INCREMENT_INGEST_HIVE_TYPE#'$INCREMENT_INGEST_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "incrementalfailoverjob" ]]; then
   appName="incrementalfailoverjob-$2"
   className=com.aciworldwide.ra.redi.rstransflow.actions.TransFlowFailedAction
   appConfig= 

   driverMemory=$INCREMENT_FAILOVER_DRIVER_MEMORY
   executorMemory=$INCREMENT_FAILOVER_EXECUTOR_MEMORY
   numberOfExecutors=$INCREMENT_FAILOVER_NUM_OF_EXECUTOR
   executorCores=$INCREMENT_FAILOVER_NUM_OF_CORE
   queueName=$INCREMENT_FAILOVER_QUEUE_NAME

   sed -i -e 's#INCREMENT_FAILOVER_CHECKPOINTLOCATION#'$INCREMENT_FAILOVER_CHECKPOINTLOCATION'#g' $appConfig
   sed -i -e 's#INCREMENT_FAILOVER_TOPICS#'$INCREMENT_FAILOVER_TOPICS'#g' $appConfig
   sed -i -e 's#INCREMENT_FAILOVER_MSG_TYPE#'$INCREMENT_FAILOVER_MSG_TYPE'#g' $appConfig
   sed -i -e 's#INCREMENT_FAILOVER_GROUP_ID#'$INCREMENT_FAILOVER_GROUP_ID'#g' $appConfig
   sed -i -e 's#INCREMENT_FAILOVER_HIVE_DBURI#'$INCREMENT_FAILOVER_HIVE_DBURI'#g' $appConfig
   sed -i -e 's#INCREMENT_FAILOVER_HIVE_DBNAME#'$INCREMENT_FAILOVER_HIVE_DBNAME'#g' $appConfig
   sed -i -e 's#INCREMENT_FAILOVER_HIVE_TYPE#'$INCREMENT_FAILOVER_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "IncrementalTransfJobID" ]]; then
   appName="IncrementalTransfJobID-$2"
   className=com.aciworldwide.ra.redi.rstransflow.actions.TransFlowProcessAction
   appConfig= 
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true "$extraConf

   driverMemory=$INCREMENT_TRANSFORM_DRIVER_MEMORY
   executorMemory=$INCREMENT_TRANSFORM_EXECUTOR_MEMORY
   numberOfExecutors=$INCREMENT_TRANSFORM_NUM_OF_EXECUTOR
   executorCores=$INCREMENT_TRANSFORM_NUM_OF_CORE
   queueName=$INCREMENT_TRANSFORM_QUEUE_NAME

   sed -i -e 's#INCREMENT_TRANSFORM_CHECKPOINTLOCATION#'$INCREMENT_TRANSFORM_CHECKPOINTLOCATION'#g' $appConfig
   sed -i -e 's#INCREMENT_TRANSFORM_TOPICS#'$INCREMENT_TRANSFORM_TOPICS'#g' $appConfig
   sed -i -e 's#INCREMENT_TRANSFORM_MSG_TYPE#'$INCREMENT_TRANSFORM_MSG_TYPE'#g' $appConfig
   sed -i -e 's#INCREMENT_TRANSFORM_GROUP_ID#'$INCREMENT_TRANSFORM_GROUP_ID'#g' $appConfig
   sed -i -e 's#INCREMENT_TRANSFORM_HIVE_DBURI#'$INCREMENT_TRANSFORM_HIVE_DBURI'#g' $appConfig
   sed -i -e 's#INCREMENT_TRANSFORM_HIVE_DBNAME#'$INCREMENT_TRANSFORM_HIVE_DBNAME'#g' $appConfig
   sed -i -e 's#INCREMENT_TRANSFORM_HIVE_TYPE#'$INCREMENT_TRANSFORM_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "IncrementalTransfJobID-One" ]]; then
   appName="IncrementalTransfJobID-One-$2"
   className=com.aciworldwide.ra.redi.rstransflow.actions.TransFlowProcessAction
   appConfig=$APP_HOME/$2/redi-historical/conf/rsexec-base-producer.conf
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true --conf "spark.executor.extraClassPath=./application.conf,./encryptor.properties" --conf spark.hive.vectorized.execution.enabled=false --conf spark.network.timeout=600s --conf spark.task.maxFailures=8 "$extraConf

   driverMemory=$ONE_INCREMENT_TRANSFORM_DRIVER_MEMORY
   executorMemory=$ONE_INCREMENT_TRANSFORM_EXECUTOR_MEMORY
   numberOfExecutors=$ONE_INCREMENT_TRANSFORM_NUM_OF_EXECUTOR
   executorCores=$ONE_INCREMENT_TRANSFORM_NUM_OF_CORE
   queueName=$ONE_INCREMENT_TRANSFORM_QUEUE_NAME

   name="clientgroup1"
   sed -i -e 's#ONE_INCREMENT_TRANSFORM_CHECKPOINTLOCATION#'$ONE_INCREMENT_TRANSFORM_CHECKPOINTLOCATION'#g' $appConfig
   sed -i -e 's#ONE_INCREMENT_TRANSFORM_TOPICS#'$ONE_INCREMENT_TRANSFORM_TOPICS'#g' $appConfig
   sed -i -e 's#ONE_INCREMENT_TRANSFORM_MSG_TYPE#'$ONE_INCREMENT_TRANSFORM_MSG_TYPE'#g' $appConfig
   sed -i -e 's#ONE_INCREMENT_TRANSFORM_GROUP_ID#'$ONE_INCREMENT_TRANSFORM_GROUP_ID'#g' $appConfig
   sed -i -e 's#ONE_INCREMENT_TRANSFORM_HIVE_DBURI#'$ONE_INCREMENT_TRANSFORM_HIVE_DBURI'#g' $appConfig
   sed -i -e 's#ONE_INCREMENT_TRANSFORM_HIVE_DBNAME#'$ONE_INCREMENT_TRANSFORM_HIVE_DBNAME'#g' $appConfig
   sed -i -e 's#ONE_INCREMENT_TRANSFORM_HIVE_TYPE#'$ONE_INCREMENT_TRANSFORM_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "IncrementalTransfJobID-Two" ]]; then
   appName="IncrementalTransfJobID-Two-$2"
   className=com.aciworldwide.ra.redi.rstransflow.actions.TransFlowProcessAction
   appConfig=$APP_HOME/$2/redi-historical/conf/rsexec-base-producer.conf
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true --conf "spark.executor.extraClassPath=./application.conf,./encryptor.properties" --conf spark.hive.vectorized.execution.enabled=false --conf spark.network.timeout=600s --conf spark.task.maxFailures=8 "$extraConf

   driverMemory=$TWO_INCREMENT_TRANSFORM_DRIVER_MEMORY
   executorMemory=$TWO_INCREMENT_TRANSFORM_EXECUTOR_MEMORY
   numberOfExecutors=$TWO_INCREMENT_TRANSFORM_NUM_OF_EXECUTOR
   executorCores=$TWO_INCREMENT_TRANSFORM_NUM_OF_CORE
   queueName=$TWO_INCREMENT_TRANSFORM_QUEUE_NAME

   name="clientgroup2"
   sed -i -e 's#TWO_INCREMENT_TRANSFORM_CHECKPOINTLOCATION#'$TWO_INCREMENT_TRANSFORM_CHECKPOINTLOCATION'#g' $appConfig
   sed -i -e 's#TWO_INCREMENT_TRANSFORM_TOPICS#'$TWO_INCREMENT_TRANSFORM_TOPICS'#g' $appConfig
   sed -i -e 's#TWO_INCREMENT_TRANSFORM_MSG_TYPE#'$TWO_INCREMENT_TRANSFORM_MSG_TYPE'#g' $appConfig
   sed -i -e 's#TWO_INCREMENT_TRANSFORM_GROUP_ID#'$TWO_INCREMENT_TRANSFORM_GROUP_ID'#g' $appConfig
   sed -i -e 's#TWO_INCREMENT_TRANSFORM_HIVE_DBURI#'$TWO_INCREMENT_TRANSFORM_HIVE_DBURI'#g' $appConfig
   sed -i -e 's#TWO_INCREMENT_TRANSFORM_HIVE_DBNAME#'$TWO_INCREMENT_TRANSFORM_HIVE_DBNAME'#g' $appConfig
   sed -i -e 's#TWO_INCREMENT_TRANSFORM_HIVE_TYPE#'$TWO_INCREMENT_TRANSFORM_HIVE_TYPE'#g' $appConfig
fi

if [[ $3 == "RSExecBaseHiveYBConsumer" ]]; then
   appName="rsexec-base-hive-consumer-$2"
   className=com.aciworldwide.ra.redi.rstransflow.actions.TransFlowProcessAction
   appConfig=$APP_HOME/$2/redi-historical/conf/rsexec-base-hive-consumer.conf
   extraConf=" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true --conf "spark.executor.extraClassPath=./rsexec-base-hive-consumer.conf,./encryptor.properties" --conf spark.cleaner.ttl=3600  --conf "spark.driver.extraClassPath=./rsexec-base-hive-consumer.conf,./encryptor.properties"  --conf spark.datasource.hive.warehouse.use.spark23x.specific.reader=false "$extraConf

   driverMemory=$HIST_BASE_CONSUMER_DRIVER_MEMORY
   executorMemory=$HIST_BASE_CONSUMER_EXECUTOR_MEMORY
   numberOfExecutors=$HIST_BASE_CONSUMER_NUM_OF_EXECUTOR
   executorCores=$HIST_BASE_CONSUMER_NUM_OF_CORE
   queueName=$HIST_BASE_CONSUMER_QUEUE_NAME

   sed -i -e 's#HIST_BASE_CONSUMER_CHECKPOINTLOCATION#'$HIST_BASE_CONSUMER_CHECKPOINTLOCATION'#g' $appConfig
   sed -i -e 's#HIST_BASE_CONSUMER_TOPICS#'$HIST_BASE_CONSUMER_TOPICS'#g' $appConfig
   sed -i -e 's#HIST_BASE_CONSUMER_MSG_TYPE#'$HIST_BASE_CONSUMER_MSG_TYPE'#g' $appConfig
   sed -i -e 's#HIST_BASE_CONSUMER_GROUP_ID#'$HIST_BASE_CONSUMER_GROUP_ID'#g' $appConfig
   sed -i -e 's#HIST_BASE_CONSUMER_HIVE_DBURI#'$HIST_BASE_CONSUMER_HIVE_DBURI'#g' $appConfig
   sed -i -e 's#HIST_BASE_CONSUMER_HIVE_DBNAME#'$HIST_BASE_CONSUMER_HIVE_DBNAME'#g' $appConfig
   sed -i -e 's#HIST_BASE_CONSUMER_HIVE_TYPE#'$HIST_BASE_CONSUMER_HIVE_TYPE'#g' $appConfig
fi


if [[ $1 == "start" ]] || [[ $1 == "restart" ]]; then
    # Replace parameters from environment
    sed -i -e 's#BOOTSTRAP_SERVERS#'$BOOTSTRAP_SERVERS'#g' $appConfig
    sed -i -e 's#KAFKA_KEYSTORE_PASSWORD#'$KAFKA_KEYSTORE_PASSWORD'#g' $appConfig
    sed -i -e 's#KAFKA_KEYSTORE#'$KAFKA_KEYSTORE'#g' $appConfig
    sed -i -e 's#KAFKA_TRUSTSTORE_PASSWORD#'$KAFKA_TRUSTSTORE_PASSWORD'#g' $appConfig
    sed -i -e 's#KAFKA_TRUSTSTORE#'$KAFKA_TRUSTSTORE'#g' $appConfig
    sed -i -e 's#KAFKA_KEY_PASSWORD#'$KAFKA_KEY_PASSWORD'#g' $appConfig
    sed -i -e 's#JAASCONF#'$JAASCONF'#g' $appConfig

    # Spark submit
    applicatonID=$(yarn application -appStates RUNNING -list|grep $appName|awk '{print $1}')
    if [ -z "$applicatonID" ]; then
       echo "Starting application: $appName"
       spark-submit --master yarn \
       --name $appName \
       --driver-memory $driverMemory \
       --executor-memory $executorMemory \
       --num-executors $numberOfExecutors  \
       --executor-cores $executorCores  \
       --queue $queueName \
       --deploy-mode cluster \
       --keytab $keyTab \
       --principal $principal \
       --conf spark.security.credentials.hiveserver2.enabled=false \
       --conf spark.yarn.submit.waitAppCompletion=false \
       $extraConf \
       --conf "$extraDriverOptions" \
       --conf "$extraExecutorOptions" \
       --files "$appConfig,$jaasConf,$certs,$log4j,$encryptor,$kafkaKeytabs" \
       --jars $CLASSPATH \
       --class $className $appJAR
       exit $?
    else
       echo 'Application is already RUNNING and ID='$applicatonID
       exit 0
    fi
fi

if [[ $1 == "stop" ]]; then
    # Yarn kill
    echo "Stopping job: $appName"
    yarn application -appStates RUNNING -list | grep $appName | awk '{print $1}' | while read app; do echo "yarn application -kill $app";yarn application -kill $app; done;
    exit $?
fi

if [[ $1 == "status" ]]; then
    ## read status:  0 - FINISHED, 1 - RUNNING, 2 - FAILED

    echo "Reading job status: $appName"
    statusValue=0
    applicatonID=$(yarn application -appStates RUNNING -list|grep $appName|awk '{print $1}')
    if [ -n "$applicatonID" ]; then
       echo 'Application is RUNNING and ID='$applicatonID
       statusValue=1
    else
       applicatonID=$(yarn application -appStates FAILED -list|grep $appName|awk '{print $1}')
       if [ -n "$applicatonID" ]; then
          echo 'Application is FAILED and ID='$applicatonID
          statusValue=2
       fi
    fi

    exit $statusValue
fi

# done!

