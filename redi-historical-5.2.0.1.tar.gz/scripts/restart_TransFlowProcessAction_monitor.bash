#!/bin/bash
# Description  :This Script is used to monitor the job and whenever job fails auto restart the job.
#
# Modification history:
#
# Date         Author               Description
# ===========  ===================  ============================================
# 04/11/2017   Anand Ayyasamy       Creation
# 17/10/2019	Mayank M			Modified 
################################################################################

MOVED to generic restart script, Please REMOVE THIS SCRIPT


###APP_NAME="Allclientgroup"
CLUSTER_NAME="Norcross_Hadoop_UAT"
RESTART_PATH="/user/srvredi/scheduledRestart"

while true
        do
        st=$(yarn application -appStates RUNNING -list | grep $APP_NAME | awk '{print $2}')

        if [ -z "$st" ]
        then
			restart=$(hdfs dfs -ls $RESTART_PATH)
			if [ -z "$restart" ]
			then
			echo " $CLUSTER_NAME - $APP_NAME is NOT RUNNING, going to restart now. Review the failed yarn application logs. " | mailx -s " $CLUSTER_NAME - $APP_NAME is NOT RUNNING, going to restart now " midhun.polisetty@aciworldwide.com kiruba.venkatesh@aciworldwide.com
					./TransFlowProcessAction.sh
			else
				echo "Scheduled restart, no need to alert. Restarting the Job"
					./TransFlowProcessAction.sh
					remove=$(hdfs dfs -rm -r $RESTART_PATH/*)
			fi
        else
                  echo " $APP_NAME is RUNNING, No action required"
        fi

sleep 120
done
