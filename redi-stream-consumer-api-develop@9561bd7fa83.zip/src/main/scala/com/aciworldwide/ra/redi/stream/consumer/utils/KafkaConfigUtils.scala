/*
# Program      : KafkaConfigUtils.scala
# Date Created : 05/12/2019
# Description  : This is the used get the kafka producer/producer config
# Parameters   :
#
# Modification history:
# Kafka constance : https://kafka.apache.org/22/javadoc/constant-values.html
# Date         Author               Description
# ===========  ===================  ============================================
# 06/24/2019   Anand Ayyasamy        Creation
# ===========  ===================  =============================================
*/
package com.aciworldwide.ra.redi.stream.consumer.utils

import org.apache.kafka.clients.CommonClientConfigs._
import org.apache.kafka.common.config.SslConfigs._
import org.apache.kafka.common.config.SaslConfigs._

object KafkaConfigUtils {

  /*Kafka prefix value for each property*/
  private val KAFKA_PREFIX = "kafka."
  /*starting offset*/
  private val STARTING_OFFSET = "startingOffsets"
  /*consumer topics*/
  final val CONSUMER_TOPICS = "kafka.consumer.topics"
  /*producer topics*/
  final val PRODUCER_TOPICS = "kafka.producer.topics"
  /*topic name from schema registry*/
  final val SCHEMA_REGISTRY_TOPIC = "schema.registry.topic"

  /**
   * Consumer Config used for Structured streaming
   *
   * @param props
   * @return
   */
  def getConsumerMap(props: Map[String, String]): Map[String, String] = {
    val params = Map[String, String](
      KAFKA_PREFIX + BOOTSTRAP_SERVERS_CONFIG -> props(KAFKA_PREFIX + BOOTSTRAP_SERVERS_CONFIG),
      "subscribe" -> props(CONSUMER_TOPICS),
      STARTING_OFFSET -> props(KAFKA_PREFIX + STARTING_OFFSET),
      "failOnDataLoss" -> "false",
      KAFKA_PREFIX + SECURITY_PROTOCOL_CONFIG -> props(KAFKA_PREFIX + SECURITY_PROTOCOL_CONFIG),
      KAFKA_PREFIX + SASL_KERBEROS_SERVICE_NAME -> props(KAFKA_PREFIX + SASL_KERBEROS_SERVICE_NAME),
      KAFKA_PREFIX + SSL_TRUSTSTORE_LOCATION_CONFIG -> props(KAFKA_PREFIX + SSL_TRUSTSTORE_LOCATION_CONFIG),
      KAFKA_PREFIX + SSL_TRUSTSTORE_PASSWORD_CONFIG -> props(KAFKA_PREFIX + SSL_TRUSTSTORE_PASSWORD_CONFIG),
      KAFKA_PREFIX + SSL_KEYSTORE_LOCATION_CONFIG -> props(KAFKA_PREFIX + SSL_KEYSTORE_LOCATION_CONFIG),
      KAFKA_PREFIX + SSL_KEYSTORE_PASSWORD_CONFIG -> props(KAFKA_PREFIX + SSL_KEYSTORE_PASSWORD_CONFIG),
      KAFKA_PREFIX + SSL_KEY_PASSWORD_CONFIG -> props(KAFKA_PREFIX + SSL_KEY_PASSWORD_CONFIG)
    )
    params
  }


}