package com.aciworldwide.ra.redi.stream.consumer.utils

import org.apache.spark.internal.Logging
import org.apache.spark.sql.{DataFrame, Dataset}
import org.apache.spark.sql.functions.{col, explode_outer, from_json}
import org.apache.spark.sql.types.{DataType, StructType}
import za.co.absa.abris.avro.AvroSerDe._
import za.co.absa.abris.avro.schemas.policy.SchemaRetentionPolicies.RETAIN_SELECTED_COLUMN_ONLY


/*
# Program      : StreamUtils.scala
# Date Created : 05/12/2020
# Description  : Schema slicer
# Parameters   :
#
# Modification history:
#
# Date         Author               Description
# ===========  ===================  ============================================
# 05/15/2020 Anand Ayyasamy        Creation
# ===========  ===================  =============================================
*/
@SerialVersionUID(111L)
object StreamUtils extends Logging {


  /**
   * prepare LLAP options for writer
   *
   * @param dbNm
   * @param tblNm
   * @param metaUri
   * @return
   */
  def llapOpts(dbNm: String, tblNm: String, metaUri: String): Map[String, String] = {
    val params = Map[String, String]("database" -> dbNm, "table" -> tblNm, "metastoreUri" -> metaUri)
    params
  }

  /**
   * This method is used slice the datasets based on JSON schema
   *
   * @param ds
   * @param schemaInfo
   * @return DataFrames
   */
  def slicer4Obj(ds: DataFrame, schemaInfo: StructType): DataFrame = {
    ds.select(from_json(col(ds.columns.apply(0)), schemaInfo) as "dta")
      .select("dta.*")
  }

  /**
   * This method is used slice the nested datasets[List/Map] based on JSON schema
   *
   * @param ds
   * @param schemaInfo
   * @return DataFrames
   */
  def slicer4ArrayOrMaps(ds: DataFrame, schemaInfo: StructType): DataFrame = {
    val df1 = ds.select(from_json(col(ds.columns.apply(0)), schemaInfo) as "dta")
      .select("dta.*")
    df1.select(explode_outer(col(df1.columns.apply(0))) as "dta1")
      .select("dta1.*")
  }


  /**
   * Datasets based on kafka consumer record type.
   *
   * @param kcmt
   * @param df
   * @param schemaRegMap
   * @return df
   */
  def kakaConsumerRecordType(kcmt: String, df: DataFrame, schemaRegMap: Map[String, String]): DataFrame = {
    if (kcmt.equalsIgnoreCase("Avro"))
      df.fromConfluentAvro("value", None, Some(schemaRegMap))(RETAIN_SELECTED_COLUMN_ONLY)
    df.selectExpr("CAST(value AS STRING)")

  }

}

