package com.aciworldwide.ra.redi.stream.consumer

import java.io.FileInputStream
import java.util.Properties

import com.aciworldwide.ra.redi.stream.consumer.constants.AppConstants._
import com.aciworldwide.ra.redi.stream.consumer.utils.KafkaConfigUtils
import com.aciworldwide.ra.redi.stream.consumer.utils.StreamUtils.{llapOpts, slicer4ArrayOrMaps, slicer4Obj}
import com.hortonworks.hwc.HiveWarehouseSession
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.{DataType, StructType}

import scala.collection.JavaConverters._

object
BiConsumers extends App with Logging {
  // load and set application conf
  private val prop = new Properties()
  prop.load(new FileInputStream(System.getProperties.getProperty("app.config.name"))) // Read config from property file
  private val pm = prop.asScala.toMap
  val processTm = pm(STREAMING_TIME)
  val nof = pm(DF_WR_NOF).toInt
  // kafka config
  val kcMap = KafkaConfigUtils.getConsumerMap(pm)
  // LLAP or YB
  val dbUri = pm(DB_URI)
  val dbNm = pm(DB_NAME)
  val tblNms = pm(TABLE_NAMES).split(",")
  val IsBarrowTbl = pm(ENABLE_NARROR).toBoolean
  // schema
  val mstrSchema = DataType.fromJson(pm(MSTR_SCHEMA)).asInstanceOf[StructType]
  val dtlsSchema = DataType.fromJson(pm(DTLS_SCHEMA)).asInstanceOf[StructType]
  val rhSchema = DataType.fromJson(pm(RULE_HITS_SCHEMA)).asInstanceOf[StructType]
  val mstrNarrowSchema = DataType.fromJson(pm(MSTR_NARROW_SCHEMA)).asInstanceOf[StructType]
  logInfo("launch spark application")
  val spark = SparkSession
    .builder()
    .appName(pm(APP_NAME))
    .getOrCreate()
  spark.conf.set(CHECKPOINT_LOC, pm(CHECKPOINT_LOC))

  try {
    // Read from kafka write into Hive
    logInfo("Streaming starts ...")
    val ksDs = spark
      .readStream
      .format("kafka")
      .options(kcMap)
      .load()
      .selectExpr("CAST(value AS STRING)")

    val mstrSink = slicer4Obj(ksDs, mstrSchema)
      .coalesce(nof)
      .writeStream
      .format(HiveWarehouseSession.STREAM_TO_STREAM)
      .options(llapOpts(dbNm, tblNms.apply(0), dbUri))
      .trigger(Trigger.ProcessingTime(processTm))
      .start()

    val dtlsSink = slicer4ArrayOrMaps(ksDs, dtlsSchema)
      .coalesce(nof)
      .writeStream
      .format(HiveWarehouseSession.STREAM_TO_STREAM)
      .options(llapOpts(dbNm, tblNms.apply(1), dbUri))
      .trigger(Trigger.ProcessingTime(processTm))
      .start()

    val rhSink = slicer4ArrayOrMaps(ksDs, rhSchema)
      .coalesce(nof)
      .writeStream
      .format(HiveWarehouseSession.STREAM_TO_STREAM)
      .options(llapOpts(dbNm, tblNms.apply(2), dbUri))
      .trigger(Trigger.ProcessingTime(processTm))
      .start()
    if (IsBarrowTbl) {
      val mstrNrwSink = slicer4Obj(ksDs, mstrNarrowSchema)
        .coalesce(nof)
        .writeStream
        .format(HiveWarehouseSession.STREAM_TO_STREAM)
        .options(llapOpts(dbNm, tblNms.apply(3), dbUri))
        .trigger(Trigger.ProcessingTime(processTm))
        .start()
      mstrNrwSink.awaitTermination()
    }
    mstrSink.awaitTermination()
    dtlsSink.awaitTermination()
    rhSink.awaitTermination()
  }

  catch {
    case exc: Exception => {
      logError(exc.getMessage, exc.fillInStackTrace())
      sys.exit(1)
    }
  }
  finally {
    spark.stop()
    logInfo("Closing the SparkSession")
    sys.exit(0)
  }


}
