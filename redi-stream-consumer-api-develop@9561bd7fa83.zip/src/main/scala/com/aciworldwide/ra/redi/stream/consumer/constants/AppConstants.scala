
package com.aciworldwide.ra.redi.stream.consumer.constants

/**
 * This specifies the different properties mentiond in configuration files
 * in hdfs , whic is being reused.
 *
 */
object AppConstants {
  //Spark
  final val APP_NAME = "app.name"
  final val STREAMING_TIME = "spark.sql.streaming.duration.seconds"
  final val DF_WR_NOF = "spark.df.wr.no.files"
  final val CHECKPOINT_LOC = "spark.sql.streaming.checkpointLocation"
  //Consumer group id
  final val CONSUMER_GROUP = "kafka.consumer.group"
  final val SCHEMA_REGISTRY_URL = "schema.registry.url"

  //producer topic 
  final val PRODUCER_TOPICS = "kafka.producer.topics"
  /*spark context log level*/
  final val LOG_LEVEL = "spark.context.log.level"

  //destination table schema
  final val MSTR_SCHEMA = "txn.master.json.schema"
  final val DTLS_SCHEMA = "txn.details.json.schema"
  final val RULE_HITS_SCHEMA = "tx.rule.hits.json.schema"
  final val MSTR_NARROW_SCHEMA = "txn.master.narrow.json.schema"
  final val TBL_SCHEMA = "table.json.schema"
  // llap/YB
  final val DB_URI = "db.uri"
  final val DB_NAME = "db.name"
  final val DB_TYPE = "db.type"
  final val TABLE_NAMES = "db.table.names"
  final val ENABLE_NARROR = "enable.narrow.tbl"


}