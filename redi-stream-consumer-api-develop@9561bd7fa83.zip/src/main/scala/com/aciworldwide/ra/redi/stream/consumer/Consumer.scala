package com.aciworldwide.ra.redi.stream.consumer

import java.io.FileInputStream
import java.util.Properties
import com.aciworldwide.ra.redi.stream.consumer.constants.AppConstants._
import com.aciworldwide.ra.redi.stream.consumer.utils.KafkaConfigUtils
import com.aciworldwide.ra.redi.stream.consumer.utils.StreamUtils.{llapOpts, slicer4ArrayOrMaps, slicer4Obj}
import com.hortonworks.hwc.HiveWarehouseSession
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.{DataType, StructType}
import scala.collection.JavaConverters._

object
Consumer extends App with Logging {
  // load and set application conf
  private val prop = new Properties()
  prop.load(new FileInputStream(System.getProperties.getProperty("app.config.name"))) // Read config from property file
  private val pm = prop.asScala.toMap
  val processTm = pm(STREAMING_TIME)
  val nof = pm(DF_WR_NOF).toInt
  // kafka config
  val kcMap = KafkaConfigUtils.getConsumerMap(pm)
  /*LLAP*/
  val metaUri = pm(DB_URI)
  val dbNm = pm(DB_NAME)
  val tblNm = pm("db.table.name")
  // schema
  val tblSchema = DataType.fromJson(pm("table.json.schema")).asInstanceOf[StructType]
  logInfo("launch spark application")
  val spark = SparkSession
    .builder()
    .appName(pm(APP_NAME))
    .getOrCreate()

  spark.conf.set(CHECKPOINT_LOC, pm(CHECKPOINT_LOC))
  try {

    // Read from kafka
    logInfo("Streaming starts ...")
    val ksDs = spark
      .readStream
      .format("kafka")
      .options(kcMap)
      .load()
      .selectExpr("CAST(value AS STRING)")
    // After slicing the data write into HIVE
    val tblSink = slicer4Obj(ksDs, tblSchema)
      .coalesce(nof) // control no files been created
      .writeStream
      .format(HiveWarehouseSession.STREAM_TO_STREAM)
      .options(llapOpts(dbNm, tblNm, metaUri))
      .trigger(Trigger.ProcessingTime(processTm))
      .start()
    tblSink.awaitTermination()

  }
  catch {
    case exc: Exception => {
      logError(exc.getMessage, exc.fillInStackTrace())
      sys.exit(1)
    }
  }
  finally {
    spark.stop()
    logInfo("Closing the SparkSession")
    sys.exit(0)
  }


}
