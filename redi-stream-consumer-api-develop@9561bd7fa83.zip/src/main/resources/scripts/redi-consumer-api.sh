#!/usr/bin/env bash

#----------------------------------------------------------------------------------------------------
# Name          : redi-consumer-api.sh
#
# Purpose       : Used for starting, restarting, stopping and reading status of a given
#                 service (aka job)
#
# App/Services  : STREAM CONSUMER API Microservice and Services offered are
#                 Consumer
#                 BiConsumers
#
#----------------------------------------------------------------------------------------------------

# Check arguments
if [[ $# != 3 ]]; then
   echo "Usage: $0 <start/stop> <app version> <job name>"
   echo "Example: $0 start 1.0-SNAPSHOT Consumer"
   echo "Example: $0 stop 1.0-SNAPSHOT Consumer"
   echo "Example: $0 restart 1.0-SNAPSHOT Consumer"
   echo "Example: $0 status 1.0-SNAPSHOT Consumer"
   exit 1
fi


# App name and location
appJAR=$APP_HOME/$2/redi-consumer-api/redi-consumer-api-$2.jar

CLASSPATH=/apps/ReDi/ReDi_ext_jars/abris_2.11-2.2.2.jar,\
/apps/ReDi/ReDi_ext_jars/avro-1.8.2.jar,\
/apps/ReDi/ReDi_ext_jars/common-config-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/common-metrics-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/common-utils-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-fw-common-impl-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-fw-spec-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-slf4j-adf-log-common-binder-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-testbundles-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/core-upf-installer-jaxb-4.1.0.0.jar,\
/apps/ReDi/ReDi_ext_jars/encryptor-1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-avro-serializer-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-clients-2.1.0-cp2.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-schema-registry-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-schema-registry-client-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/kafka-streams-avro-serde-5.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/org.osgi.core-4.1.0.jar,\
/apps/ReDi/ReDi_ext_jars/spark-sql-kafka-0-10_2.11-2.3.2.3.1.0.10-1.jar,\
/usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.0.175-5.jar,\
/apps/ReDi/lib/avro-1.8.2.jar,\
/apps/ReDi/lib/log4j-core-2.11.1.jar,\
/apps/ReDi/lib/log4j-api-2.11.1.jar,\
/apps/ReDi/lib/ojdbc6-11.2.0.3.jar,\
/apps/ReDi/lib/config-1.3.2.jar,\
/usr/share/java/kafka-rest/annotations-3.0.1.jar,\
/usr/share/java/kafka-rest/avro-1.8.1.jar,\
/usr/share/java/kafka-rest/commons-compress-1.8.1.jar,\
/usr/share/java/kafka-rest/common-utils-4.1.2.jar,\
/usr/share/java/kafka-rest/jackson-core-asl-1.9.13.jar,\
/usr/share/java/kafka-rest/jackson-mapper-asl-1.9.13.jar,\
/usr/share/java/kafka-rest/jcip-annotations-1.0.jar,\
/usr/share/java/kafka-rest/jline-0.9.94.jar,\
/usr/share/java/kafka-rest/jopt-simple-5.0.4.jar,\
/usr/share/java/kafka-rest/jsr305-3.0.1.jar,\
/usr/share/java/kafka-rest/kafka_2.11-1.1.1-cp1.jar,\
/usr/share/java/kafka-rest/kafka-avro-serializer-4.1.2.jar,\
/usr/share/java/kafka-rest/kafka-clients-1.1.1-cp1.jar,\
/usr/share/java/kafka-rest/kafka-json-serializer-4.1.2.jar,\
/usr/share/java/kafka-rest/kafka-rest-4.1.2.jar,\
/usr/share/java/kafka-rest/kafka-schema-registry-client-4.1.2.jar,\
/usr/share/java/kafka-rest/log4j-1.2.17.jar,\
/usr/share/java/kafka-rest/lz4-java-1.4.1.jar,\
/usr/share/java/kafka-rest/metrics-core-2.2.0.jar,\
/usr/share/java/kafka-rest/netty-3.10.5.Final.jar,\
/usr/share/java/kafka-rest/paranamer-2.7.jar,\
/usr/share/java/kafka-rest/scala-library-2.11.12.jar,\
/usr/share/java/kafka-rest/scala-logging_2.11-3.8.0.jar,\
/usr/share/java/kafka-rest/scala-reflect-2.11.12.jar,\
/usr/share/java/kafka-rest/slf4j-api-1.7.25.jar,\
/usr/share/java/kafka-rest/slf4j-log4j12-1.7.25.jar,\
/usr/share/java/kafka-rest/snappy-java-1.1.7.1.jar,\
/usr/share/java/kafka-rest/xz-1.5.jar,\
/usr/share/java/kafka-rest/zkclient-0.10.jar,\
/usr/share/java/kafka-rest/zookeeper-3.4.10.jar,\
/usr/share/java/confluent-common/build-tools-4.1.0.jar,\
/usr/share/java/confluent-common/common-config-4.1.0.jar,\
/usr/share/java/confluent-common/common-metrics-4.1.0.jar,\
/usr/share/java/confluent-common/common-utils-4.1.0.jar,\
/usr/share/java/confluent-common/jline-0.9.94.jar,\
/usr/share/java/confluent-common/log4j-1.2.17.jar,\
/usr/share/java/confluent-common/netty-3.10.5.Final.jar,\
/usr/share/java/confluent-common/slf4j-api-1.7.25.jar,\
/usr/share/java/confluent-common/zkclient-0.10.jar,\
/usr/share/java/confluent-common/zookeeper-3.4.10.jar,\
/apps/ReDi/lib/ReDi_common-5.2-SNAPSHOT.jar

## App level config
keyTab=$KEYTAB
principal=$PRINCIPAL
jaasConf=$JAASCONFPATH/$JAASCONFFILE
encryptor=$ENCRYPTORPROPERTIES
certs=$SCHEMAREGPATH/$SCHEMAREGFILE
log4j=$APP_HOME/$2/redi-consumer-api/conf/log4j.properties
kafkaKeytabs=$KEYTABKAFKA

JVM_JAAS="-Djava.security.auth.login.config="$JAASCONFFILE
JVM_TRUSTSTORE="-Djavax.net.ssl.trustStore="$SCHEMAREGFILE
extraConf=" --conf \"spark.driver.extraJavaOptions=-Dapp.config.name=bi-app.properties -Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE\" --conf \"spark.executor.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE\"  "

if [[ $SCHEMAREGPATH == "" ]]; then
   certs=
fi

if [[ $JAASCONFPATH == "" ]]; then
   jaasConf=
fi


if [[ $METRICS_ENABLED == "Y" ]]; then
   extraConf=" --conf \"spark.driver.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9015 -Dcom.sun.management.jmxremote.local.only=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-driver-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf \"spark.executor.extraJavaOptions=-Duser.timezone=UTC $JVM_JAAS $JVM_TRUSTSTORE -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -Xloggc:/tmp/gc-redi-streaming-ds-hive-executor-$now.log -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/tmp\" --conf spark.sql.streaming.metricsEnabled=true "
fi

filesConf=" --files \"$jaasConf,$certs,$log4j,$encryptor,$kafkaKeytabs\"  "

if [[ $3 == "Consumer" ]]; then
    appName="redi-k2hive-consumer-baestream-$2"
    appConfig=$APP_HOME/$2/redi-consumer-api/conf/application.properties
    extraConf=" --conf spark.authenticate=true "$extraConf
    className=com.aciworldwide.ra.redi.stream.consumer.$3
    
    driverMemory=$CONSUMER_DRIVER_MEMORY
    executorMemory=$CONSUMER_EXECUTOR_MEMORY
    numberOfExecutors=$CONSUMER_NUM_OF_EXECUTOR
    executorCores=$CONSUMER_NUM_OF_CORE
    queueName=$CONSUMER_QUEUE_NAME

    sed -i -e 's#CONSUMER_CHECKPOINTLOCATION#'$CONSUMER_CHECKPOINTLOCATION'#g' $appConfig
    sed -i -e 's#CONSUMER_TOPICS#'$CONSUMER_TOPICS'#g' $appConfig
    sed -i -e 's#CONSUMER_MSG_TYPE#'$CONSUMER_MSG_TYPE'#g' $appConfig
    sed -i -e 's#CONSUMER_GROUP_ID#'$CONSUMER_GROUP_ID'#g' $appConfig
    sed -i -e 's#CONSUMER_HIVE_DBURI#'$CONSUMER_HIVE_DBURI'#g' $appConfig
    sed -i -e 's#CONSUMER_HIVE_DBNAME#'$CONSUMER_HIVE_DBNAME'#g' $appConfig
    sed -i -e 's#CONSUMER_HIVE_TYPE#'$CONSUMER_HIVE_TYPE'#g' $appConfig
fi


if [[ $3 == "BiConsumer" ]]; then
    appName="redi-bi-hive-consumer-$2"
    appConfig=$APP_HOME/$2/redi-consumer-api/conf/bi-app.properties
    className=com.aciworldwide.ra.redi.stream.consumer.$3

    driverMemory=$BICONSUMER_DRIVER_MEMORY
    executorMemory=$BICONSUMER_EXECUTOR_MEMORY
    numberOfExecutors=$BICONSUMER_NUM_OF_EXECUTOR
    executorCores=$BICONSUMER_NUM_OF_CORE
    queueName=$BICONSUMER_QUEUE_NAME

    sed -i -e 's#BICONSUMER_CHECKPOINTLOCATION#'$BICONSUMER_CHECKPOINTLOCATION'#g' $appConfig
    sed -i -e 's#BICONSUMER_TOPICS#'$BICONSUMER_TOPICS'#g' $appConfig
    sed -i -e 's#BICONSUMER_MSG_TYPE#'$BICONSUMER_MSG_TYPE'#g' $appConfig
    sed -i -e 's#BICONSUMER_GROUP_ID#'$BICONSUMER_GROUP_ID'#g' $appConfig
    sed -i -e 's#BICONSUMER_HIVE_DBURI#'$BICONSUMER_HIVE_DBURI'#g' $appConfig
    sed -i -e 's#BICONSUMER_HIVE_DBNAME#'$BICONSUMER_HIVE_DBNAME'#g' $appConfig
    sed -i -e 's#BICONSUMER_HIVE_TYPE#'$BICONSUMER_HIVE_TYPE'#g' $appConfig
fi


if [[ $1 == "start" ]] || [[ $1 == "restart" ]]; then
    # Replace parameters from environment
    sed -i -e 's#BOOTSTRAP_SERVERS#'$BOOTSTRAP_SERVERS'#g' $appConfig
    sed -i -e 's#KAFKA_KEYSTORE_PASSWORD#'$KAFKA_KEYSTORE_PASSWORD'#g' $appConfig
    sed -i -e 's#KAFKA_KEYSTORE#'$KAFKA_KEYSTORE'#g' $appConfig
    sed -i -e 's#KAFKA_TRUSTSTORE_PASSWORD#'$KAFKA_TRUSTSTORE_PASSWORD'#g' $appConfig
    sed -i -e 's#KAFKA_TRUSTSTORE#'$KAFKA_TRUSTSTORE'#g' $appConfig
    sed -i -e 's#KAFKA_KEY_PASSWORD#'$KAFKA_KEY_PASSWORD'#g' $appConfig

    # Spark submit
    applicatonID=$(yarn application -appStates RUNNING -list|grep $appName|awk '{print $1}')
    if [ -z "$applicatonID" ]; then
       echo "Initializing..."
       kinit $principal -k -t $keyTab

       echo "Starting application: $appName"
       spark-submit --master yarn \
       --name $appName \
       --driver-memory $driverMemory \
       --executor-memory $executorMemory \
       --num-executors $numberOfExecutors  \
       --executor-cores $executorCores  \
       --queue $queueName \
       --deploy-mode cluster \
       --keytab $keyTab \
       --principal $principal \
       --conf spark.serializer=org.apache.spark.serializer.KryoSerializer \
       --conf spark.memory.fraction=0.8  \
       --conf spark.scheduler.maxRegisteredResourcesWaitingTime=60s \
       --conf spark.memory.storageFraction=0.5 \
       --conf spark.cleaner.periodicGC.interval=10min \
       --conf spark.streaming.receiver.maxRate="5000" \
       --conf spark.streaming.kafka.maxRatePerPartition="1000" \
       --conf spark.security.credentials.hiveserver2.enabled=false \
       --conf spark.yarn.kerberos.relogin.period=10m \
       --conf spark.yarn.submit.waitAppCompletion=false \
         $extraConf \
         $filesConf \
       --jars $appConfig,$CLASSPATH \
       --class $className $appJAR
       exit $?
    else
       echo 'Application is already RUNNING and ID='$applicatonID
       exit 0
    fi
fi

if [[ $1 == "stop" ]]; then
    # Yarn kill
    echo "Stopping job: $appName"
    yarn application -appStates RUNNING -list | grep $appName | awk '{print $1}' | while read app; do echo "yarn application -kill $app";yarn application -kill $app; done;
    exit $?
fi

if [[ $1 == "status" ]]; then
    ## read status:  0 - FINISHED, 1 - RUNNING, 2 - FAILED

    echo "Reading job status: $appName"
    statusValue=0
    applicatonID=$(yarn application -appStates RUNNING -list|grep $appName|awk '{print $1}')
    if [ -n "$applicatonID" ]; then
       echo 'Application is RUNNING and ID='$applicatonID
       statusValue=1
    else
       applicatonID=$(yarn application -appStates FAILED -list|grep $appName|awk '{print $1}')
       if [ -n "$applicatonID" ]; then
          echo 'Application is FAILED and ID='$applicatonID
          statusValue=2
       fi
    fi

    exit $statusValue
fi

# done!

