#!/usr/bin/env bash
### Usage   : bi-hive-consumers.sh start/stop
### Author  : Anand Ayyasamy
### Details : The scripts is used to start/stop spark application

MOVE TO redi-stream-consumer.sh, Pease REMOVE THIS LATER
#auth
principal=srvredi@IPA.AM.TSACORP.COM
keyTab=/home/srvredi/keytabs/srvredi.keytab
jaasConf=/home/srvredi/auth/jaas.conf
kinit $principal -k -t $keyTab

# App
appName="redi-bi-consumers"
appPath=$(dirname -- "$PWD")
# Lib
libPath=/home/srvredi/common-lib
depLib=/usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-*.jar,$libPath/kafka-clients-2.1.0.jar,$libPath/spark-streaming-kafka-0-10_2.11-2.3.2.jar,$libPath/spark-sql-kafka-0-10_2.11-2.3.2.jar,$libPath/jackson-core-2.8.8.jar,$libPath/jackson-databind-2.8.7.jar,$libPath/jackson-annotations-2.8.7.jar,$libPath/abris_2.11-2.2.2.jar,$libPath/common-utils-5.1.0.jar,$libPath/common-metrics-5.1.0.jar,$libPath/common-config-5.1.0.jar,$libPath/kafka-schema-registry-client-5.1.0.jar,$libPath/kafka-schema-registry-5.1.0.jar,$libPath/kafka-avro-serializer-5.1.0.jar,$libPath/avro-1.8.2.jar,$libPath/kafka-streams-avro-serde-5.1.0.jar,$libPath/spark-avro_2.11-4.0.0.jar,$libPath/encryptor-1.0.jar,$libPath/core-fw-common-impl-4.1.0.0.jar,$libPath/core-fw-spec-4.1.0.0.jar,$libPath/core-upf-installer-jaxb-4.1.0.0.jar,$libPath/chronicle-*.jar,$libPath/affinity-3.1.13.jar

if [[ $# != 1 ]]; then
   echo "Do you want 'stat/stop' application "
   exit 1
fi

# app st
st="$1"

if [[ $1 == "start" ]]; then
 echo "Starting job: $appName"


# Spark submit

spark-submit --master yarn --name $appName \
--driver-memory 8G --executor-memory 4G --num-executors 2  --executor-cores 8  --queue ReDi-Stream --deploy-mode cluster \
--keytab $keyTab --principal $principal \
--jars $appPath/conf/bi-app.properties,$depLib \
--files "$jaasConf,$appPath/conf/log4j.properties" \
--conf spark.serializer=org.apache.spark.serializer.KryoSerializer \
--conf spark.memory.fraction=0.8  \
--conf spark.yarn.submit.waitAppCompletion=false \
--conf spark.memory.storageFraction=0.5 \
--conf spark.cleaner.periodicGC.interval=10min \
--conf spark.scheduler.maxRegisteredResourcesWaitingTime=60s \
--conf spark.streaming.receiver.maxRate="5000" \
--conf spark.streaming.kafka.maxRatePerPartition="1000" \
--conf spark.security.credentials.hiveserver2.enabled=false \
--conf "spark.driver.extraJavaOptions=-Dlog4j.configuration=log4j.properties -Duser.timezone=UTC -Djava.security.auth.login.config=jaas.conf -Djavax.net.ssl.trustStore=keytore" \
--conf "spark.executor.extraJavaOptions=-Dlog4j.configuration=log4j.properties -Duser.timezone=UTC -Djava.security.auth.login.config=jaas.conf -Djavax.net.ssl.trustStore=keytore" \--conf spark.authenticate=true \
--conf spark.yarn.kerberos.relogin.period=10m \
--class com.aciworldwide.ra.redi.stream.consumer.BiConsumers \
$appPath/lib/redi-consumer-api-*.jar
# done!
    exit $?
fi

if [[ $1 == "stop" ]]; then
    # Yarn kill
    echo "Stopping job: $appName"
    yarn application -appStates RUNNING -list | grep $appName | awk '{print $1}' | while read app; do echo "yarn application -kill $app";yarn application -kill $app; done;
    exit $?
fi

